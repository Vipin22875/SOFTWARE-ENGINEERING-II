import tkinter
import webbrowser
from College_Menu import *
from PIL import ImageTk, Image
from tkinter import messagebox
    

root = None
userbox = None
passbox = None
topframe = None
bottomframe = None
frame3 = None
login = None
club=None

def __information__():
       filename = 'College_Std_info_FrontEnd.py'
      # os.system(filename)
       os.system("python3 "+filename)

def __information_admin__():
       filename = 'College_Admin_info_Frontend.py'
      # os.system(filename)
       os.system("python3 "+filename)


# command for login button
def GET():
    global userbox, passbox, error
    S1 = userbox.get()
    S2 = passbox.get()
    if (S1 == 'v' and S2 == '1'):
        # menu()
        __information_admin__();
    elif(S1 == "1" and S2 == "1"):
         __information__()
    else:
        error = tkinter.Label(bottomframe, text="\tWrong Id / Password TRY AGAIN", fg="red", font="bold")
        error.pack(side=tkinter.TOP)
        error.pack()
#CLUBS

new = 1
url1 = "https://www.coepzest.org/#"
url2 = "https://www.coep.org.in/campus_festivals/mindspark"
url3 = "https://www.coepregatta.com/"
url4 =  "https://www.punestartupfest.in/"

def club_1():
    webbrowser.open(url1)

def club_2():
    webbrowser.open(url2)

def club_3():
    webbrowser.open(url3)

def club_4():
    webbrowser.open(url4)

def ms():
    global Button_2_VIEWREPORT
    club_2()

def reg():
    global Button_3_VIEWREPORT
    club_3()

def zest():
    global Button_1_VIEWREPORT
    club_1()

def psf():
    global Button_4_VIEWREPORT
    club_4()
def clubs():
       root = Tk()
       root.title('CLUBS')
       root.geometry('1350x750')
       root.config(bg = 'yellow')
       
       Menu_title_Frame = LabelFrame(root, font = ('arial',50,'bold'), width = 1000, height = 100, bg = 'navajo white', relief = 'raise', bd = 13)
       Menu_title_Frame.grid(row = 0, column = 0, pady = 50)
       
       Menu_title_Label = Label(Menu_title_Frame, text = 'CLUBS', font = ('arial',30,'bold'), bg = 'navajo white')
       Menu_title_Label.grid(row = 0, column = 0, padx = 150)


       #========================================================FRAMES===================================================================
       Menu_Frame_1 = LabelFrame(root, font = ('arial',17,'bold'), width = 1000, height = 100, bg = 'navajo white', relief = 'ridge', bd = 10)
       Menu_Frame_1.grid(row = 1, column = 0, padx = 280)
       Menu_Frame_2 = LabelFrame(root, font = ('arial',17,'bold'), width = 1000, height = 100, bg = 'navajo white', relief = 'ridge', bd = 10)
       Menu_Frame_2.grid(row = 2, column = 0, padx = 130, pady = 7)
       Menu_Frame_3 = LabelFrame(root, font = ('arial',17,'bold'), width = 1000, height = 100, bg = 'navajo white', relief = 'ridge', bd = 10)
       Menu_Frame_3.grid(row = 3, column = 0, pady = 7)
       Menu_Frame_4 = LabelFrame(root, font = ('arial',17,'bold'), width = 1000, height = 100, bg = 'navajo white', relief = 'ridge', bd = 10)
       Menu_Frame_4.grid(row = 4, column = 0, pady = 7)



       #========================================================LABELS===================================================================
       Label_1_STUDENTINFO = Label(Menu_Frame_1, text = 'ZEST', font = ('arial',25,'bold'), bg = 'navajo white')
       Label_1_STUDENTINFO.grid(row = 0, column = 0, padx = 50, pady = 5)
       Label_2_FEEREPORT = Label(Menu_Frame_2, text = 'MINDSPARKS', font = ('arial',25,'bold'), bg = 'navajo white')
       Label_2_FEEREPORT.grid(row = 0, column = 0, padx = 100, pady = 5)
       Label_3_LIBRARYSYSTEM = Label(Menu_Frame_3, text = 'REGATTA', font = ('arial',25,'bold'), bg = 'navajo white')
       Label_3_LIBRARYSYSTEM.grid(row = 0, column = 0, padx = 60, pady = 5)
       Label_4_MARKSHEET = Label(Menu_Frame_4, text = 'PSF', font = ('arial',25,'bold'), bg = 'navajo white')
       Label_4_MARKSHEET.grid(row = 0, column = 0, padx = 101, pady = 5)
       


       #========================================================BUTTONS===================================================================
       Button_1_VIEWINFO = Button(Menu_Frame_1, text = 'VIEW', font = ('arial',16,'bold'), width = 8, command = zest)
       Button_1_VIEWINFO.grid(row = 0, column = 3, padx = 50)
       Button_2_VIEWREPORT = Button(Menu_Frame_2, text = 'VIEW', font = ('arial',16,'bold'), width = 8, command = ms)
       Button_2_VIEWREPORT.grid(row = 0, column = 3, padx = 50)
       Button_3_VIEWLIBRARY = Button(Menu_Frame_3, text = 'VIEW', font = ('arial',16,'bold'), width = 8, command = reg)
       Button_3_VIEWLIBRARY.grid(row = 0, column = 3, padx = 50)
       Button_4_VIEWMARKSHEET = Button(Menu_Frame_4, text = 'VIEW', font = ('arial',16,'bold'), width = 8, command = psf)
       Button_4_VIEWMARKSHEET.grid(row = 0, column = 3, padx = 50)
     
       root.mainloop()
#ACHIEVEMENTS
url5 = "https://www.coep.org.in/achievements"

def acheive1():
    webbrowser.open(url5)

def ac():
    global Button_5_VIEWREPORT
    acheive1()

def achieves():
       Button_5_VIEWINFO = Button(root, text = 'ACHIEVEMENTS', font = ('arial',16,'bold'), width = 8, command = ac)
       Button_5_VIEWINFO.grid(row = 5, column = 7, padx = 50)
# LOGIN PAGE WINDOW
def Entry():
    global userbox, passbox, login,topframe, bottomframe, image_1,club,achieve
    root = tkinter.Tk()
    root.geometry('1350x750')   
    root.config(bg='steelblue')
    # top = Tk()

    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "college1.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)

    C.pack()
    root.mainloop

    heading = tkinter.Label(root, text="Welcome To Educational Intitute",bg='steelblue', fg='black', font='Times 24')
    username = tkinter.Label(root, text="USERNAME")
    userbox = tkinter.Entry(root)
    password = tkinter.Label(root, text="PASSWORD")
    passbox = tkinter.Entry(root, show="*")
    login = tkinter.Button(root, text="LOGIN", bg='yellow', command=GET, font="arial 8 bold")
    heading.pack(side=tkinter.TOP)
    heading.place(x=155, y=30)
    username.pack(side=tkinter.TOP)
    username.place(x=185, y=100)
    userbox.pack(side=tkinter.TOP)
    userbox.place(x=285, y=100)
    password.pack(side=tkinter.TOP)
    password.place(x=185, y=140)
    passbox.pack(side=tkinter.TOP)
    passbox.place(x=285, y=140)
    login.pack(side=tkinter.TOP)
    login.place(x=310, y=180)
    root.title("COLLEGE LOGIN")
    club = tkinter.Button(root, text="CLUB", bg='yellow', command=clubs, font="arial 8 bold")
    club.pack(side=tkinter.TOP)
    club.place(x=185, y=180)
    achieve = tkinter.Button(root, text="ACHIEVEMENTS", bg='yellow', command=ac, font="arial 8 bold")
    achieve.pack(side=tkinter.TOP)
    achieve.place(x=435, y=180)
    root.mainloop()


Entry()
