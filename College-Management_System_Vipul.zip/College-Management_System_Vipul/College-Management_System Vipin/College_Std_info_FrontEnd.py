from tkinter import*
import tkinter.messagebox  
import random
from tokenize import String
import College_Std_info_BackEnd
import College_Marksheet_Backend
from tkinter import ttk
import os

class Student_Information():
       def __init__(self, master):
              self.master = master
              self.master.title('Student Information')
              self.master.geometry('1350x750')
              self.master.config(bg = 'navajowhite')
              
              def information():

                     self.name = StringVar()
                     self.father_name = StringVar()
                     self.mother_name = StringVar()
                     self.address = StringVar()
                     self.mobileno = StringVar()
                     self.email_address = StringVar()
                     self.date_of_birth = StringVar()
                     self.gender = StringVar()
                     self.marks = StringVar()
                     self.number = StringVar()
                     


                     def Student_Record(event):
                            try: 
                                   global selected_tuple
                                   
                                   index = self.listbox.curselection()[0]
                                   selected_tuple = self.listbox.get(index)

                                   self.Text_Entry_name.delete(0, END)
                                   self.Text_Entry_name.insert(END, selected_tuple[1])
                                   self.Text_Entry_Father_Name.delete(0, END)
                                   self.Text_Entry_Father_Name.insert(END, selected_tuple[2])
                                   self.Text_Entry_Mother_Name.delete(0, END)
                                   self.Text_Entry_Mother_Name.insert(END, selected_tuple[3])
                                   self.Text_Entry_address.delete(0, END)
                                   self.Text_Entry_address.insert(END, selected_tuple[4])
                                   self.Text_Entry_mobileno.delete(0, END)
                                   self.Text_Entry_mobileno.insert(END, selected_tuple[5])
                                   self.Text_Entry_email_address.delete(0, END)
                                   self.Text_Entry_email_address.insert(END, selected_tuple[6])
                                   self.Text_Entry_date_of_birth.delete(0, END)
                                   self.Text_Entry_date_of_birth.insert(END, selected_tuple[7])
                                   self.Text_Entry_gender.delete(0, END)
                                   self.Text_Entry_gender.insert(END, selected_tuple[8])
                                   self.Text_Entry_number.delete(0, END)
                                   self.Text_Entry_number.insert(END, selected_tuple[9])
                                   
                            except IndexError:
                                   pass


                     def Add():
                            if(len(self.name.get()) != 0):
                               College_Std_info_BackEnd.insert(self.name.get(), self.father_name.get(), self.mother_name.get(), self.address.get(), self.mobileno.get(), self.email_address.get(), self.date_of_birth.get(), \
                                                               self.gender.get(), self.number.get())
                               self.listbox.delete(0, END)
                               self.listbox.insert(END, (self.name.get(), self.father_name.get(), self.mother_name.get(), self.address.get(), self.mobileno.get(), self.email_address.get(), self.date_of_birth.get(), \
                                                         self.gender.get(),self.number.get()))

                     def Display():
                            # self.listbox.delete(0, END)
                            # for row in College_Std_info_BackEnd.view():
                            #        self.listbox.insert(END, row, str(' '))
                            #        # break
                            if(len(self.number.get()) != 0):
                                   try:
                                          row = College_Std_info_BackEnd.view(self.number.get())
                                          print(row)
                                          # College_Std_info_BackEnd.search_result_marksheet(row)
                                          self.listbox.insert(END,row,str(''))
                                   except:
                                          tkinter.messagebox.askokcancel('Attention','Please enter valid Roll No.')
                                          return
                     

                     
                     def __marksheet__():
                               filename = 'Marksheet_Search.py'
			       #os.system(filename)
                               os.system("python3 "+filename)


                     def Exit():
                            Exit = tkinter.messagebox.askyesno("Login System", "Confirm if you want to Exit")
                            if Exit > 0:
                                   self.master.destroy()
                                   return 
                            

                     self.Student_Main_Frame = LabelFrame(self.master, width = 1300, height = 500, font = ('arial', 20, 'bold'), \
                                                          bg = 'navajowhite', bd = 15, relief = 'ridge')
                     self.Student_Main_Frame.grid(row = 0, column = 0, padx = 10, pady = 20)

                     self.Student_Frame_1 = LabelFrame(self.Student_Main_Frame, width = 600, height = 400, font = ('arial', 15, 'bold'), \
                                                       relief = 'ridge', bd = 10, bg = 'navajowhite', text = 'STUDENT INFORMATION ')
                     self.Student_Frame_1.grid(row = 1, column = 0, padx = 10)

                     self.Student_Frame_2 = LabelFrame(self.Student_Main_Frame, width = 750, height = 400, font = ('arial', 15, 'bold'), \
                                                       relief = 'ridge', bd = 10, bg = 'navajowhite', text = 'STUDENT DATABASE')
                     self.Student_Frame_2.grid(row = 1, column = 1, padx = 5)
                     
                     self.Student_Frame_3 = LabelFrame(self.master, width = 1200, height = 100, font = ('arial', 10, 'bold'), \
                                                       bg = 'navajowhite', relief = 'ridge', bd = 13)
                     self.Student_Frame_3.grid(row = 2, column = 0, pady = 10)


                     

                     self.lbl_Name = Label(self.Student_Frame_1, text ='Name', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_Name.grid(row = 0, column = 0, sticky = W, padx = 20, pady = 10)
                     self.lbl_father_name = Label(self.Student_Frame_1, text ='Father Name', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_father_name.grid(row = 1, column = 0, sticky = W, padx = 20)
                     self.lbl_mother_name = Label(self.Student_Frame_1, text ='Mother Name', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_mother_name.grid(row = 2, column = 0, sticky = W, padx = 20)
                     self.lbl_address = Label(self.Student_Frame_1, text ='Address', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_address.grid(row = 3, column = 0, sticky = W, padx = 20)
                     self.lbl_mobileno = Label(self.Student_Frame_1, text ='Mobile Number', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_mobileno.grid(row = 4, column = 0, sticky = W, padx = 20)
                     self.lbl_email_address = Label(self.Student_Frame_1, text ='Email Address', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_email_address.grid(row = 5, column = 0, sticky = W, padx = 20)
                     self.lbl_dateOf_birth = Label(self.Student_Frame_1, text ='Date of Birth', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_dateOf_birth.grid(row = 6, column = 0, sticky = W, padx = 20)
                     self.lbl_gender = Label(self.Student_Frame_1, text ='Gender', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_gender.grid(row = 7, column = 0, sticky = W, padx = 20, pady = 10)
                     self.lbl_number = Label(self.Student_Frame_1, text ='ROLL', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     self.lbl_number.grid(row = 9, column = 0, sticky = W, padx = 20, pady = 10)
                     

                     #self.lbl_marks = Label(self.Student_Frame_1, text ='Marksheet', font = ('arial', 20, 'bold'), bg ='navajowhite')
                     #self.lbl_marks.grid(row = 9, column = 0, sticky = W, padx = 20, pady = 10)



                     self.Text_Entry_name = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.name)
                     self.Text_Entry_name.grid(row = 0, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_Father_Name = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.father_name)
                     self.Text_Entry_Father_Name.grid(row = 1, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_Mother_Name = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.mother_name)
                     self.Text_Entry_Mother_Name.grid(row = 2, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_address = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.address)
                     self.Text_Entry_address.grid(row = 3, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_mobileno = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.mobileno)
                     self.Text_Entry_mobileno.grid(row = 4, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_email_address = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.email_address)
                     self.Text_Entry_email_address.grid(row = 5, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_date_of_birth = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.date_of_birth)
                     self.Text_Entry_date_of_birth.grid(row = 6, column = 1, padx = 10, pady = 5)
                     self.Text_Entry_gender = ttk.Combobox(self.Student_Frame_1, values = (' ', 'Male', 'Female', 'Others'), \
                                                           font = ('arial',17,'bold'), textvariable = self.gender, width = 19)
                     self.Text_Entry_gender.grid(row = 7, column = 1, padx = 10, pady = 5)
                     self.Text_number = Entry(self.Student_Frame_1, font = ('arial', 17, 'bold'), textvariable = self.number)
                     self.Text_number.grid(row = 9, column = 1, padx = 10, pady = 5)
                     

                    # self.Text_Entry_marks = ttk.Combobox(self.Student_Frame_1, values = (' ', '10', '11', '12'), \
                            #                               font = ('arial',17,'bold'), textvariable = self.marks, width = 19)
#                     self.Text_Entry_marks.grid(row = 9, column = 1, padx = 10, pady = 5)
                     




                     self.SAVE_BUTTON = Button(self.Student_Frame_3, text ='SAVE', font = ('arial', 17, 'bold'), width = 8, command = Add)
                     self.SAVE_BUTTON.grid(row = 0, column = 0, padx = 10, pady = 10)
                     self.BUTTON_DISPLAY = Button(self.Student_Frame_3, text ='DISPLAY', font = ('arial', 17, 'bold'), width = 8, command = Display)
                     self.BUTTON_DISPLAY.grid(row = 0, column = 1, padx = 10, pady = 10)
                     
                     self.MARKS_BUTTON = Button(self.Student_Frame_3, text ='MARKSHEET', font = ('arial', 17, 'bold'), width = 10, command = __marksheet__)
                     self.MARKS_BUTTON.grid(row = 2, column = 0, padx = 10, pady = 10)
                     self.BUTTON_EXIT = Button(self.Student_Frame_3, text ='EXIT', font = ('arial', 17, 'bold'), width = 8, command = Exit)
                     self.BUTTON_EXIT.grid(row = 0, column = 6, padx = 10, pady = 10)



                     
                     self.scrollbar = Scrollbar(self.Student_Frame_2)
                     self.scrollbar.grid(row = 0, column = 1, sticky = 'ns')

                     self.listbox = Listbox(self.Student_Frame_2, width = 75, height = 20, font = ('arial', 12, 'bold'))
                     self.listbox.bind('<<ListboxSelect>>', Student_Record)
                     self.listbox.grid(row = 0, column = 0)
                     self.scrollbar.config(command = self.listbox.yview)
                            
              information()
                     

root = Tk()
obj = Student_Information(root)
root.mainloop()
